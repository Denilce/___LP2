﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo__
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("KG");
            listBox1.Items.Add("PC");
            listBox1.Items.Add("UN");
            listBox1.Items.Add("LT");
            listBox1.Items.Add("G");
            listBox1.Items.Add("M");
            listBox1.Sorted = true;
            listBox1.SelectedIndex = 0;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="")
            {
                MessageBox.Show("Descrição Vazia");
            }
            else
            {
                MessageBox.Show(textBox1.Text);
            }

            if (checkBox1.Checked)
            {
                MessageBox.Show("Produto é importado!");
            }
            else
            {
                MessageBox.Show("Produto NÃO é importado!");

            }

            if (comboBox1.SelectedIndex ==  -1) 
            {
                MessageBox.Show("Fornecedor não selecionado!");
            }
            else
            {
                MessageBox.Show("Fornecedor: "+comboBox1.SelectedItem);
            }

            if (radioButton1.Checked)
            {
                MessageBox.Show("Faz parte da cesta básica");
            }
            else
            {
                MessageBox.Show("Não faz parte da cesta básica");
            }

            string stringona = "";

            for (int i = 0;i < checkedListBox1.CheckedItems.Count;i++) 
            {
               stringona += "\n" + checkedListBox1.CheckedItems[i].ToString();
            }

            MessageBox.Show(stringona);

            double preco;
            
            if (Double.TryParse(maskedTextBox1.Text,out preco))
            {
                if (preco <= 0)
                {
                    MessageBox.Show("Preço deve ser maior que zero");
                }
                else
                {
                    MessageBox.Show(preco.ToString());
                }
            }

            DateTime data;

            if (DateTime.TryParse(maskedTextBox2.Text, out data))
            {
                MessageBox.Show(data.ToString("dd/MM/yyyy"));
            }
            else
            {
                MessageBox.Show("Data inválida!");
            }
        }
    }
}
